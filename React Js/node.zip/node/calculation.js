function sum(){
    return 50;
}

function minus(){
    return 100;
}


// For Node Js
// module.exports = { sum, minus }


// For React
export {  sum, minus };