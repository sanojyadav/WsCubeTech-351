function division(){
    return 150;
}


export default division;