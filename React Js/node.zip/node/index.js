// const { sum, minus } = require("./calculation");   // Node JS

import division from "./calc.js";
import { minus, sum } from "./calculation.js"; // React

var a = 25;
var b = 15;

var c = a*b;


console.log(sum());
console.log(minus());
console.log(division());